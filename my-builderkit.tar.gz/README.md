# All-in-one AI Platform - BuilderKit Pro

This is a comprehensive AI platform built with Next.js 14.2.3, Tailwind CSS, shadcn/ui, and Supabase, migrated to the BuilderKit-Pro architecture.

## Features

- 🔐 **Authentication**: Google OAuth and email/password authentication via Supabase
- 🎨 **Image Generation**: Create images using DALL-E 3, DALL-E 2, and Stable Diffusion
- 🏠 **Interior Design**: AI-powered room redesign and decoration suggestions
- 💬 **Chat Assistant**: Intelligent conversations with multiple AI models
- 🎤 **Voice Synthesis**: Text-to-speech with ElevenLabs
- 📹 **Video Generation**: Create videos from text prompts
- 📄 **Document Analysis**: Extract insights from documents
- 💻 **Code Assistant**: AI-powered coding help
- 🧠 **AI Models Explorer**: Discover and test various AI models
- 💳 **Billing Integration**: Stripe and LemonSqueezy payment processing

## Tech Stack

- **Framework**: Next.js 14.2.3 (App Router)
- **Styling**: Tailwind CSS + shadcn/ui
- **Database**: Supabase (PostgreSQL)
- **Authentication**: Supabase Auth + NextAuth
- **AI Services**:
  - OpenAI (GPT-4, DALL-E)
  - Anthropic (Claude)
  - Together AI
  - ElevenLabs
  - Stability AI
- **Payments**: Stripe & LemonSqueezy
- **State Management**: React Context + SWR/React Query
- **Type Safety**: TypeScript

## Getting Started

### Prerequisites

- Node.js 18+
- npm/yarn/pnpm
- Supabase account
- API keys for AI services

### Installation

1. Clone the repository:
```bash
git clone https://github.com/your-org/my-builderkit.git
cd my-builderkit
```

2. Install dependencies:
```bash
npm install
```

3. Set up environment variables:
Copy `.env.local.example` to `.env.local` and fill in your keys:
```env
# Supabase
NEXT_PUBLIC_SUPABASE_URL=your_supabase_url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_supabase_anon_key
SUPABASE_SERVICE_KEY=your_service_key
SUPABASE_JWT_SECRET=your_jwt_secret

# NextAuth
NEXTAUTH_URL=http://localhost:3000
NEXTAUTH_SECRET=your_nextauth_secret

# AI Services
OPENAI_API_KEY=your_openai_key
TOGETHER_API_KEY=your_together_key
ELEVENLABS_API_KEY=your_elevenlabs_key

# Payments
STRIPE_SECRET_KEY=your_stripe_secret
STRIPE_PUBLISHABLE_KEY=your_stripe_publishable
LEMONSQUEEZY_API_KEY=your_lemonsqueezy_key
```

4. Set up the database:
Run the migrations in your Supabase dashboard to create the required tables:
- `users`
- `activities`
- `ai_agents`
- `ai_models`
- `chat_sessions`
- `chat_messages`
- `analytics_data`
- `usage_tracking`
- `user_api_keys`

5. Run the development server:
```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) to see the application.

## Project Structure

```
my-builderkit/
├── src/
│   ├── app/                    # Next.js App Router
│   │   ├── (auth)/            # Auth group (login, signup)
│   │   ├── (app)/             # Protected app group
│   │   │   └── dashboard/     # Dashboard and tools
│   │   ├── api/               # API routes
│   │   └── layout.tsx         # Root layout
│   ├── components/            # React components
│   │   ├── ui/               # shadcn/ui components
│   │   └── auth/             # Auth-related components
│   ├── contexts/             # React contexts
│   ├── lib/                  # Utilities and configurations
│   │   └── supabase/         # Supabase client
│   └── pages/api/ai/         # AI API handlers (if using Pages Router)
├── public/                    # Static assets
├── styles/                    # Global styles
└── package.json
```

## Key Features Implementation

### Authentication Flow
- Users can sign in with Google OAuth or email/password
- Protected routes redirect to login if not authenticated
- Session management with Supabase Auth

### AI Tools
Each tool has its own page under `/dashboard/[tool]` with:
- Dedicated UI for tool-specific inputs
- Real-time processing feedback
- Result display and download options
- Usage tracking and analytics

### Database Schema
- **RLS Policies**: Row Level Security enabled on all tables
- **User Scoping**: All data is scoped to the authenticated user
- **Activity Tracking**: All AI tool usage is logged

### API Architecture
- RESTful API routes under `/api/ai/`
- Serverless functions for each AI service
- Error handling and rate limiting
- Request/response logging

## Deployment

### Vercel (Recommended)
1. Push your code to GitHub
2. Import the repository in Vercel
3. Add environment variables
4. Deploy

### Docker
```bash
docker build -t builderkit-pro .
docker run -p 3000:3000 --env-file .env.local builderkit-pro
```

## Contributing

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add some amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Support

For support, email support@builderkit.pro or join our Discord community.

## Acknowledgments

- BuilderKit Pro team for the excellent starter template
- shadcn for the beautiful UI components
- All the AI service providers for their APIs