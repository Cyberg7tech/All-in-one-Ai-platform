import { createClient } from '@supabase/supabase-js'

// Supabase environment variables
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!

// Create a single supabase client for interacting with your database
export const supabase = createClient(supabaseUrl, supabaseAnonKey)

// Supabase configuration environment
export const supabaseEnv = {
  url: supabaseUrl,
  anonKey: supabaseAnonKey,
}

// Helper function to get service role client (server-side only)
export const getServiceSupabase = () => {
  if (typeof window !== 'undefined') {
    throw new Error('Service role client can only be used server-side')
  }
  
  const serviceKey = process.env.SUPABASE_SERVICE_KEY
  if (!serviceKey) {
    throw new Error('SUPABASE_SERVICE_KEY is not set')
  }
  
  return createClient(supabaseUrl, serviceKey, {
    auth: {
      autoRefreshToken: false,
      persistSession: false
    }
  })
}