'use client'

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Input } from '@/components/ui/input'
import { Search, Star, TrendingUp, Clock, Zap } from 'lucide-react'

const models = [
  {
    id: 1,
    name: 'GPT-4 Turbo',
    provider: 'OpenAI',
    category: 'Text Generation',
    description: 'Most capable GPT-4 model with improved instruction following',
    rating: 4.9,
    usage: '2.5M',
    tags: ['chat', 'coding', 'reasoning'],
  },
  {
    id: 2,
    name: 'DALL-E 3',
    provider: 'OpenAI',
    category: 'Image Generation',
    description: 'Create realistic images and art from natural language descriptions',
    rating: 4.8,
    usage: '1.8M',
    tags: ['image', 'art', 'creative'],
  },
  {
    id: 3,
    name: 'Claude 3 Opus',
    provider: 'Anthropic',
    category: 'Text Generation',
    description: 'Most powerful Claude model for complex tasks',
    rating: 4.9,
    usage: '1.2M',
    tags: ['chat', 'analysis', 'writing'],
  },
  {
    id: 4,
    name: 'Stable Diffusion XL',
    provider: 'Stability AI',
    category: 'Image Generation',
    description: 'High-resolution image generation with fine control',
    rating: 4.7,
    usage: '3.1M',
    tags: ['image', 'art', 'open-source'],
  },
  {
    id: 5,
    name: 'Whisper Large',
    provider: 'OpenAI',
    category: 'Speech Recognition',
    description: 'Robust speech recognition in multiple languages',
    rating: 4.6,
    usage: '890K',
    tags: ['audio', 'transcription', 'multilingual'],
  },
  {
    id: 6,
    name: 'ElevenLabs Multilingual',
    provider: 'ElevenLabs',
    category: 'Text to Speech',
    description: 'Natural-sounding speech synthesis in 29 languages',
    rating: 4.8,
    usage: '650K',
    tags: ['audio', 'voice', 'multilingual'],
  },
]

const templates = [
  {
    id: 1,
    name: 'Blog Post Writer',
    description: 'Generate SEO-optimized blog posts with AI',
    category: 'Writing',
    saves: '12.3K',
  },
  {
    id: 2,
    name: 'Product Description',
    description: 'Create compelling product descriptions',
    category: 'E-commerce',
    saves: '8.7K',
  },
  {
    id: 3,
    name: 'Social Media Caption',
    description: 'Engaging captions for social media posts',
    category: 'Marketing',
    saves: '15.2K',
  },
  {
    id: 4,
    name: 'Code Documentation',
    description: 'Generate clear code documentation',
    category: 'Development',
    saves: '6.5K',
  },
]

export default function ExplorePage() {
  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Explore</h1>
        <p className="text-muted-foreground">
          Discover AI models, templates, and community creations.
        </p>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <Input
          type="search"
          placeholder="Search models, templates, or tools..."
          className="pl-10"
        />
      </div>

      <Tabs defaultValue="models" className="space-y-4">
        <TabsList>
          <TabsTrigger value="models">AI Models</TabsTrigger>
          <TabsTrigger value="templates">Templates</TabsTrigger>
          <TabsTrigger value="community">Community</TabsTrigger>
        </TabsList>

        <TabsContent value="models" className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex gap-2">
              <Button variant="outline" size="sm">
                <TrendingUp className="mr-2 h-4 w-4" />
                Trending
              </Button>
              <Button variant="outline" size="sm">
                <Star className="mr-2 h-4 w-4" />
                Top Rated
              </Button>
              <Button variant="outline" size="sm">
                <Clock className="mr-2 h-4 w-4" />
                Recent
              </Button>
            </div>
          </div>

          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {models.map((model) => (
              <Card key={model.id} className="cursor-pointer transition-all hover:shadow-lg">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div>
                      <CardTitle className="text-lg">{model.name}</CardTitle>
                      <CardDescription>{model.provider}</CardDescription>
                    </div>
                    <Badge variant="secondary">{model.category}</Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-sm text-muted-foreground">{model.description}</p>
                  
                  <div className="flex flex-wrap gap-1">
                    {model.tags.map((tag) => (
                      <Badge key={tag} variant="outline" className="text-xs">
                        {tag}
                      </Badge>
                    ))}
                  </div>

                  <div className="flex items-center justify-between text-sm">
                    <div className="flex items-center gap-1">
                      <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                      <span>{model.rating}</span>
                    </div>
                    <div className="flex items-center gap-1 text-muted-foreground">
                      <Zap className="h-4 w-4" />
                      <span>{model.usage} uses</span>
                    </div>
                  </div>

                  <Button className="w-full" size="sm">
                    Try Model
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="templates" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {templates.map((template) => (
              <Card key={template.id} className="cursor-pointer transition-all hover:shadow-lg">
                <CardHeader>
                  <CardTitle className="text-lg">{template.name}</CardTitle>
                  <CardDescription>{template.description}</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <Badge>{template.category}</Badge>
                    <span className="text-sm text-muted-foreground">
                      {template.saves} saves
                    </span>
                  </div>
                  <Button className="w-full" variant="outline" size="sm">
                    Use Template
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="community" className="space-y-4">
          <div className="flex h-96 items-center justify-center rounded-lg border-2 border-dashed">
            <div className="text-center">
              <p className="text-muted-foreground">
                Community creations coming soon...
              </p>
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}