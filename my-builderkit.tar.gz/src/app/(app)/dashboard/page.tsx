'use client'

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { 
  ArrowUpRight, 
  Image, 
  MessageSquare, 
  Mic, 
  Video, 
  FileText, 
  Code, 
  Palette, 
  Brain,
  TrendingUp,
  Users,
  Activity,
  DollarSign
} from 'lucide-react'
import Link from 'next/link'

const tools = [
  {
    title: 'Image Generator',
    description: 'Create stunning images with AI',
    icon: Image,
    href: '/dashboard/image-generator',
    color: 'text-purple-600 bg-purple-100',
  },
  {
    title: 'Interior Design',
    description: 'Transform your spaces with AI',
    icon: Palette,
    href: '/dashboard/interior-design',
    color: 'text-pink-600 bg-pink-100',
  },
  {
    title: 'Chat Assistant',
    description: 'Intelligent conversations',
    icon: MessageSquare,
    href: '/dashboard/chat',
    color: 'text-blue-600 bg-blue-100',
  },
  {
    title: 'Voice Synthesis',
    description: 'Natural text-to-speech',
    icon: Mic,
    href: '/dashboard/voice',
    color: 'text-green-600 bg-green-100',
  },
  {
    title: 'Video Generator',
    description: 'Create videos from text',
    icon: Video,
    href: '/dashboard/video',
    color: 'text-red-600 bg-red-100',
  },
  {
    title: 'Document Analysis',
    description: 'Extract insights from documents',
    icon: FileText,
    href: '/dashboard/documents',
    color: 'text-orange-600 bg-orange-100',
  },
  {
    title: 'Code Assistant',
    description: 'AI-powered coding help',
    icon: Code,
    href: '/dashboard/code',
    color: 'text-indigo-600 bg-indigo-100',
  },
  {
    title: 'AI Models',
    description: 'Explore available models',
    icon: Brain,
    href: '/dashboard/models',
    color: 'text-teal-600 bg-teal-100',
  },
]

const stats = [
  {
    title: 'Total Requests',
    value: '12,345',
    change: '+12.5%',
    icon: Activity,
  },
  {
    title: 'Active Users',
    value: '1,234',
    change: '+8.2%',
    icon: Users,
  },
  {
    title: 'API Usage',
    value: '89.2%',
    change: '+2.4%',
    icon: TrendingUp,
  },
  {
    title: 'Revenue',
    value: '$12,345',
    change: '+15.3%',
    icon: DollarSign,
  },
]

export default function DashboardPage() {
  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
        <p className="text-muted-foreground">
          Welcome to your AI platform. Choose a tool to get started.
        </p>
      </div>

      {/* Stats */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {stats.map((stat) => {
          const Icon = stat.icon
          return (
            <Card key={stat.title}>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  {stat.title}
                </CardTitle>
                <Icon className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stat.value}</div>
                <p className="text-xs text-muted-foreground">
                  <span className="text-green-600">{stat.change}</span> from last month
                </p>
              </CardContent>
            </Card>
          )
        })}
      </div>

      {/* Tools Grid */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {tools.map((tool) => {
          const Icon = tool.icon
          return (
            <Link key={tool.title} href={tool.href}>
              <Card className="cursor-pointer transition-all hover:shadow-lg">
                <CardHeader>
                  <div className={`inline-flex rounded-lg p-3 ${tool.color}`}>
                    <Icon className="h-6 w-6" />
                  </div>
                  <CardTitle className="mt-4">{tool.title}</CardTitle>
                  <CardDescription>{tool.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <Button variant="ghost" className="p-0">
                    Explore <ArrowUpRight className="ml-2 h-4 w-4" />
                  </Button>
                </CardContent>
              </Card>
            </Link>
          )
        })}
      </div>

      {/* Recent Activity */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Activity</CardTitle>
          <CardDescription>Your latest AI tool usage</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="flex items-center space-x-4">
                <div className="h-10 w-10 rounded-full bg-muted" />
                <div className="flex-1 space-y-1">
                  <p className="text-sm font-medium">Generated image with DALL-E 3</p>
                  <p className="text-xs text-muted-foreground">2 hours ago</p>
                </div>
                <Button variant="outline" size="sm">
                  View
                </Button>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}