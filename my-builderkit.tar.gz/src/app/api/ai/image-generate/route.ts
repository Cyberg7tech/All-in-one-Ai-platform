import { NextRequest, NextResponse } from 'next/server'
import { OpenAI } from 'openai'
import { supabase } from '@/lib/supabase/client'

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
})

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { prompt, model, size } = body

    // Validate input
    if (!prompt) {
      return NextResponse.json(
        { error: 'Prompt is required' },
        { status: 400 }
      )
    }

    let images: string[] = []

    // Generate image based on model
    switch (model) {
      case 'dall-e-3':
      case 'dall-e-2':
        const response = await openai.images.generate({
          model,
          prompt,
          n: 1,
          size: size as any,
        })
        images = response.data.map(img => img.url || '')
        break
        
      case 'stable-diffusion':
        // TODO: Implement Stable Diffusion API call
        // For now, return a placeholder
        images = [`https://via.placeholder.com/${size.replace('x', '/')}`]
        break
        
      default:
        return NextResponse.json(
          { error: 'Invalid model selected' },
          { status: 400 }
        )
    }

    // Log activity to Supabase
    const { data: { user } } = await supabase.auth.getUser()
    if (user) {
      await supabase.from('activities').insert({
        user_id: user.id,
        type: 'image_generation',
        model,
        prompt,
        metadata: { size, images_count: images.length },
      })
    }

    return NextResponse.json({ images })
  } catch (error: any) {
    console.error('Image generation error:', error)
    return NextResponse.json(
      { error: error.message || 'Failed to generate image' },
      { status: 500 }
    )
  }
}