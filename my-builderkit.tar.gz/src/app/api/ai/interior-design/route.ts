import { NextRequest, NextResponse } from 'next/server'
import { OpenAI } from 'openai'
import { supabase } from '@/lib/supabase/client'

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
})

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData()
    const image = formData.get('image') as File
    const style = formData.get('style') as string
    const room = formData.get('room') as string
    const prompt = formData.get('prompt') as string

    if (!image) {
      return NextResponse.json(
        { error: 'Image is required' },
        { status: 400 }
      )
    }

    // Convert image to base64
    const bytes = await image.arrayBuffer()
    const buffer = Buffer.from(bytes)
    const base64Image = buffer.toString('base64')

    // Create design prompt
    const designPrompt = `Transform this ${room.replace('-', ' ')} into a ${style} style. ${prompt || ''}`

    // Use DALL-E 3 to generate the redesigned room
    // In a real implementation, you might use a specialized interior design model
    const response = await openai.images.generate({
      model: 'dall-e-3',
      prompt: `Interior design: ${designPrompt}. High quality, photorealistic, professional interior design.`,
      n: 1,
      size: '1024x1024',
    })

    const result = response.data[0]?.url || ''

    // Log activity to Supabase
    const { data: { user } } = await supabase.auth.getUser()
    if (user) {
      await supabase.from('activities').insert({
        user_id: user.id,
        type: 'interior_design',
        metadata: { style, room, has_prompt: !!prompt },
      })
    }

    return NextResponse.json({ result })
  } catch (error: any) {
    console.error('Interior design error:', error)
    return NextResponse.json(
      { error: error.message || 'Failed to process design' },
      { status: 500 }
    )
  }
}